# Masidy Studio — Setup

This adds Image Studio, Video Studio, Voice Studio, and App Builder to
`masidyai/chatbot`, using the same sidebar, theme, and shadcn components as
the rest of the app.

## What's in here

| Area | Model | Route |
|---|---|---|
| Image Studio | `nvidia/cosmos3-nano` / `nvidia/cosmos3-super` via AI Gateway | `/image` |
| Video Studio | same Cosmos3 models via AI Gateway, with optional sound | `/video` |
| Voice Studio | `Qwen/Qwen3-TTS` via **direct DeepInfra call** | `/voice` |
| App Builder | `google/gemma-4-31b-it` via AI Gateway, `generateObject` | `/app-builder` |

Image, Video, and App Builder all route through **AI Gateway** — the same
mechanism `lib/ai/providers.ts` already uses for chat — so they need no new
API key beyond what Gateway already requires (`AI_GATEWAY_API_KEY`, or
Vercel OIDC if deployed on Vercel).

## One real exception: Voice Studio needs its own key

AI Gateway doesn't route speech models yet (`gateway.speechModel` doesn't
exist as of `ai@6.0.116` / `@ai-sdk/gateway`), and `@ai-sdk/deepinfra` only
covers language + image models, not speech. So `/api/studio/voice` calls
`https://api.deepinfra.com/v1/inference/Qwen/Qwen3-TTS` directly.

Add to `.env.local`:
```
DEEPINFRA_API_KEY=your_key_here
```
Get one at https://deepinfra.com/dash/api_keys.

If this key is missing, Voice Studio returns a clear error instead of
failing silently — it won't break the rest of the app.

## Why there's no "voice" mode on Cosmos3

Cosmos3 is genuinely an omnimodal **world** model — it outputs image and
video (optionally with a baked-in soundtrack via "video-with-sound"), not
standalone narration. There's no documented Cosmos3 endpoint that takes
text and returns clean speech audio. Building Voice Studio on top of it
would have meant either faking a feature that doesn't exist or shipping
something broken, so it's wired to a real TTS model instead.

## Applying this

**Option A — patch (recommended):**
```bash
git apply masidy-studio.patch
```
Verified clean against a fresh clone of `main` as of this writing.

**Option B — manual copy:**
The zip mirrors the repo's folder structure. Most files are new — copy
them straight in. Four files are *modifications*, not new files, so
copying them in would overwrite rather than merge:
- `.env.example`
- `components/chat/app-sidebar.tsx`
- `lib/ai/models.ts`
- `lib/errors.ts`

Diff those four against your current versions before overwriting if
you've changed them since this was generated.

## A landmine that was avoided

The repo's `.gitignore` has a bare `build` rule, which silently ignores
**any** file or folder named `build` anywhere in the tree — including
route segments like `app/(studio)/build/`. That's why this is
`app/(studio)/app-builder/`, not `app/(studio)/build/`. If you ever add a
route literally called `build`, double check `git status` actually picked
it up.

## What's verified vs. what isn't

**Verified directly** (not assumed):
- `tsc --noEmit` — zero errors in any new/changed file
- `next build` (Turbopack) — all 4 new pages and all 4 new API routes
  compiled to working server bundles (`.next/server/app/(studio)/...`).
  The only build failure was the pre-existing Google Fonts fetch in the
  sandbox's restricted network — unrelated to these changes, and not an
  issue on Vercel or any normal environment.
- The patch applies cleanly against an independent fresh clone of `main`.
- Model IDs (`nvidia/cosmos3-nano`, `nvidia/cosmos3-super`,
  `google/gemma-4-26b-a4b-it`, `google/gemma-4-31b-it`) and the DeepInfra
  Cosmos3/TTS request shapes were checked against current DeepInfra/NVIDIA
  documentation, not guessed.

**Not verified** (couldn't be, from this sandbox):
- Actual end-to-end generation calls — no live `AI_GATEWAY_API_KEY` or
  `DEEPINFRA_API_KEY` available here, no outbound network to
  `deepinfra.com` or `ai-gateway.vercel.sh` from this container. The
  request/response shapes match documentation, but a live smoke test
  after deploying is worth doing before you rely on it.
- Cosmos3's *exact* JSON response field names for image/video bytes
  through the AI Gateway abstraction specifically (vs. DeepInfra's raw
  REST API, which is documented). The AI SDK's `generateImage`/
  `generateVideo` should normalize this regardless of provider, but
  Cosmos3 is a very new model on Gateway, so worth a real test run.

## Suggested next steps

1. Add `DEEPINFRA_API_KEY` to your environment
2. Apply the patch, `pnpm install`, `pnpm dev`
3. Try one generation in each studio page with real prompts
4. If Image/Video Studio errors, check the AI Gateway dashboard for
   whether `nvidia/cosmos3-nano` shows up as an available model on your
   account — very new models sometimes need to be explicitly enabled
